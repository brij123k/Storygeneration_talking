import vertexai
import os 
from vertexai.preview.generative_models import GenerativeModel, Part
import google.cloud.texttospeech as tts
from story_generation import generate

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "complete-flash-411506-1e6791534c29.json"
def generate():
  model = GenerativeModel("gemini-pro")
  responses = model.generate_content(
    """Generate an engaging and interactive adventure story suitable for a 4-year-old child. The protagonist, named \'Alex,\' wakes up one morning to discover a magical object in their room. This magical object has the power to transport Alex to different places and times.
The story should revolve around themes of adventure, honesty, and hard work. Incorporate moments where Alex faces challenges that require honesty and hard work to overcome. Make the narrative interactive, allowing for child input to influence the plot. If the child provides an input during the story, ensure that the plot adapts accordingly.
Introduce vivid descriptions, simple language, and positive messages. Additionally, include questions at key points in the story to keep the child engaged, such as \'What should Alex do next?\' or \'How can Alex solve this problem?\'
Please ensure that the generated story is age-appropriate, imaginative, and conveys positive moral values. The goal is to create an entertaining and educational adventure for a young audience.""",
    generation_config={
        "max_output_tokens": 2048,
        "temperature": 0.9,
        "top_p": 1
    },
  stream=True,
  )
  
  generated_text = ''.join(response.text if hasattr(response, 'text') else '' for response in responses)

    # Printing the entire story as a single string enclosed in double quotes
  # print('"' + generated_text + '"')
  generated_text=('"' + generated_text + '"')
  return generated_text


def text_to_wav(voice_name: str, text: str):
    # Check if the generated text is empty
    if not text:
        print("Generated text is empty. Exiting.")
        return

    # Debugging statement: print the generated text
    print("Generated text:")
    print(text)

    language_code = "-".join(voice_name.split("-")[:2])
    text_input = tts.SynthesisInput(text=text)
    voice_params = tts.VoiceSelectionParams(
        language_code=language_code, name=voice_name
    )
    audio_config = tts.AudioConfig(audio_encoding=tts.AudioEncoding.LINEAR16)

    client = tts.TextToSpeechClient()

    try:
        response = client.synthesize_speech(
            input=text_input,
            voice=voice_params,
            audio_config=audio_config,
        )

        filename = f"{voice_name}.wav"
        with open(filename, "wb") as out:
            out.write(response.audio_content)
            print(f'Generated speech saved to "{filename}"')
    except Exception as e:
        print(f"Error during text-to-speech synthesis: {e}")

if __name__ == "__main__":
    # Replace 'your-voice-name' with the actual voice name you want to use
    voice_name = 'en-AU-Neural2-A'
    
    # Generate the text
    generated_text = generate()
    print("bfefeifeugfiugeiugieguegifief",generated_text)

    # Call the function
    text_to_wav(voice_name, generated_text)

# generate()