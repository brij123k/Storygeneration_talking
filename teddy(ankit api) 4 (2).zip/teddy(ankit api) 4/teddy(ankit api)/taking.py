import os
import pyaudio
import speech_recognition as sr
import google.cloud.texttospeech as tts
import tempfile
import pygame
import webbrowser

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "complete-flash-411506-1e6791534c29.json"

def recognize_speech():
    client = sr.Recognizer()
    microphone = sr.Microphone()

    with microphone as source:
        print("Listening...")
        # Adjust the recognizer sensitivity to ambient noise
        client.adjust_for_ambient_noise(source)
        audio = client.listen(source)
    try:
        phrase = client.recognize_google(audio, language="en-US")
        print("You said:", phrase)

        # Check if the phrase contains specific keywords
        if "hello" in phrase.lower():
            return "hello"
        elif "open the chrome" in phrase.lower():
            return "open_chrome"
        elif any(keyword in phrase.lower() for keyword in ["generate the story", "tell me a story"]):
            return "generate_story"
        else:
            print("Command not recognized.")
            return None

    except sr.UnknownValueError:
        print("Sorry, could not understand audio.")
        return None
    except sr.RequestError as e:
        print("Could not request results; {0}".format(e))

def text_to_wav(text: str, voice_name: str = 'en-AU-Neural2-A'):
    # Check if the provided text is empty
    if not text:
        print("Provided text is empty. Exiting.")
        return

    language_code = "-".join(voice_name.split("-")[:2])
    text_input = tts.SynthesisInput(text=text)
    voice_params = tts.VoiceSelectionParams(
        language_code=language_code, name=voice_name
    )
    audio_config = tts.AudioConfig(audio_encoding=tts.AudioEncoding.LINEAR16)

    client = tts.TextToSpeechClient()

    try:
        response = client.synthesize_speech(
            input=text_input,
            voice=voice_params,
            audio_config=audio_config,
        )

        # Create a temporary file to save the synthesized speech
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as out:
            out.write(response.audio_content)
            print(f'Generated speech saved to "{out.name}"')
            return out.name
    except Exception as e:
        print(f"Error during text-to-speech synthesis: {e}")

def play_audio(file_path):
    pygame.mixer.init()
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        continue

if __name__ == "__main__":
    while True:
        # Keep listening continuously
        input_text = recognize_speech()
        if input_text:
            if input_text == "hello":
                # Synthesize response
                response_text = "Hello sir, how can I help you?"
                response_wav_file = text_to_wav(response_text)

                # Play the synthesized response
                play_audio(response_wav_file) 
            elif input_text == "open_chrome":
                # Open Chrome
                webbrowser.open('https://www.google.com')
                # Synthesize response
                response_text = "Chrome is opening."
                response_wav_file = text_to_wav(response_text)

                # Play the synthesized response
                play_audio(response_wav_file)
            elif input_text == "generate_story":
                # Synthesize response
                response_text = "Sure! What type of story would you like to listen to? Adventure, Mystery, Romance, or Science Fiction? or any thing else"
                response_wav_file = text_to_wav(response_text)

                # Play the synthesized response
                play_audio(response_wav_file)
        else:
            continue

