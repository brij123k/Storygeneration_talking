import google.cloud.texttospeech as tts
import os

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "complete-flash-411506-1e6791534c29.json"

def text_to_wav(voice_name: str, text: str):
    # Check if the provided text is empty
    if not text:
        print("Provided text is empty. Exiting.")
        return

    language_code = "-".join(voice_name.split("-")[:2])
    text_input = tts.SynthesisInput(text=text)
    voice_params = tts.VoiceSelectionParams(
        language_code=language_code, name=voice_name
    )
    audio_config = tts.AudioConfig(audio_encoding=tts.AudioEncoding.LINEAR16)

    client = tts.TextToSpeechClient()

    try:
        response = client.synthesize_speech(
            input=text_input,
            voice=voice_params,
            audio_config=audio_config,
        )

        filename = f"{voice_name}.wav"
        with open(filename, "wb") as out:
            out.write(response.audio_content)
            print(f'Generated speech saved to "{filename}"')
    except Exception as e:
        print(f"Error during text-to-speech synthesis: {e}")

if __name__ == "__main__":
    # Replace 'your-voice-name' with the actual voice name you want to use
    voice_name = 'en-AU-Neural2-A'
    
    # Provide the text you want to convert to speech
    provided_text = ""

    # Call the function
    text_to_wav(voice_name, provided_text)
